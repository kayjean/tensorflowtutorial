﻿from tensorflow.examples.tutorials.mnist import input_data
from tensorflow.python.framework.graph_util import convert_variables_to_constants
import tensorflow as tf

mnist = input_data.read_data_sets("MNIST/", one_hot=True)
x = tf.placeholder(tf.float32, [None, 784], name='x')
W = tf.Variable(tf.zeros([784, 10]), name='w')
b = tf.Variable(tf.zeros([10]), name='b')
y = tf.add(tf.matmul(x, W), b, name='y')
y_ = tf.placeholder(tf.float32, [None, 10], name='y_')
cross_entropy = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(
labels=y_, logits=y))
train_step = tf.train.GradientDescentOptimizer(0.01).minimize(cross_entropy)
session = tf.Session()
session.run(tf.global_variables_initializer())
for idx in range(12000):
	batch_x, batch_y = mnist.train.next_batch(100)
	session.run(train_step, feed_dict={x: batch_x, y_: batch_y})
graph = convert_variables_to_constants(session, session.graph_def,
output_node_names=['y'])
tf.train.write_graph(graph, '.', 'graph.pb', as_text=False)
session.close()
