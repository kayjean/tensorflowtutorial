from tensorflow.examples.tutorials.mnist import input_data
import tensorflow as tf

mnist = input_data.read_data_sets("MNIST/", one_hot=True)
session = tf.Session()
session.run(tf.global_variables_initializer())
f = open('graph.pb', 'rb')
graph = tf.GraphDef()
graph.ParseFromString(f.read())
x = tf.placeholder(tf.float32, [None, 784])
y = tf.import_graph_def(graph, input_map={'x:0': x}, return_elements=['y:0'])
y = y[0]
y_ = tf.placeholder(tf.float32, [None, 10])
correct_prediction = tf.equal(tf.argmax(y, 1), tf.argmax(y_, 1))
accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
print session.run(accuracy,feed_dict={x: mnist.test.images, y_: mnist.test.labels})
session.close()
